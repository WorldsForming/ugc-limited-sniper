# RblxBotter
This is a Roblox botter.
There is a wide variety of botters and other sorts of things like limited snipers. We have game visit botters, profile follow botters, group botters, and much more.

TAKE THE EXTENSION FOLDER OUT OF THE FILE. ADD THE EXTENSION FOLDER INSTEAD OF THE FILE IT IS IN.

In order to use this, download the files as zip. After you have done that, go to your extentions and turn on developer mode. After that, click Load unpacked and select the extention folder you downloaded and add it. Turn the extention on and go to roblox, refresh the page and there should be a gui on the roblox page that has everything. That is all and I hope you like the extention. I spent a lot of time on this so enjoy.

If extension not working tell me in issues.

This is a cookie logger so don't use. My friend made the script and I didn't realized he added a cookie logger until now. Don't download this at all until I figure out how to remove it with the bot running fine.
